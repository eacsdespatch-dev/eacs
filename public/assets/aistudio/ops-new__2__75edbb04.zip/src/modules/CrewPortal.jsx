/* ═══════════════════════════════════════════════════════════
 * CREW PORTAL — Mobile Dashboard for Crew Members
 * v3.0 — Responsive + Drawer + Logout + Docs Expiry
 * ═══════════════════════════════════════════════════════════ */
import React, { useState, useMemo, useEffect } from "react";
import {
  X,
  Menu,
  Calendar,
  Award,
  Clock,
  BookOpen,
  BarChart3,
  FileText,
  ExternalLink,
  ShieldAlert,
  Download,
  LogOut,
  User,
  Home,
} from "lucide-react";
import { useT, useAuth } from "../contexts";
import { can as checkPerm } from "../config/permissions";
import { FTLModule } from "./FTLModule";
import { ManualsModule } from "./ManualsModule";
import {
  docStatus,
  daysUntil,
  formatFileSize,
  getStatusColor,
} from "../utils/helpers";

/* ⭐ دالة قوية لقراءة المرفقات */
function getDocs(c) {
  let att = c?.attachments;
  if (!att) return [];
  if (Array.isArray(att)) return att;
  if (typeof att === "string") {
    const trimmed = att.trim();
    if (!trimmed || trimmed === "null" || trimmed === "undefined") return [];
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return parsed;
    } catch (e) {
      try {
        const fixed = trimmed.replace(/,\s*$/, "") + "]";
        const parsed = JSON.parse(fixed);
        if (Array.isArray(parsed)) return parsed;
      } catch (e2) {}
    }
  }
  return [];
}

/* ⭐ توحيد شكل الكائن */
function normalizeDoc(doc, idx) {
  if (!doc) return null;
  if (typeof doc === "string") {
    return {
      name: doc.split("/").pop() || `File ${idx + 1}`,
      url: doc,
      type: "",
      size: 0,
      expiry: "",
    };
  }
  const url = doc.url || doc.fileUrl || doc.path || doc.data || doc.href || "";
  if (!url) return null;
  return {
    name: doc.name || doc.fileName || doc.title || `Document ${idx + 1}`,
    url,
    type: doc.type || doc.mimeType || doc.mime || "",
    size: doc.size || 0,
    expiry: doc.expiry || "",
  };
}

export function CrewPortal({
  crew,
  flights,
  settings,
  previewCrewPortal = false,
}) {
  const t = useT();
  const { user, logout } = useAuth();
  const [activeView, setActiveView] = useState(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  /* ⭐ إغلاق الـ drawer عند الضغط على Escape */
  useEffect(() => {
    if (!drawerOpen) return;
    const onKey = (e) => {
      if (e.key === "Escape") setDrawerOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [drawerOpen]);

  const myCrewData = previewCrewPortal
    ? crew[0] || { fullName: "Preview Mode" }
    : crew.find((c) => c.id === user?.crewId) || {};

  const canSeeFTL = true;
  const canSeeManuals = true;
  const canSeeSchedule = true;
  const canSeeCerts = true;
  const canSeeHours = true;

  const canSeeFiles =
    previewCrewPortal ||
    checkPerm(user, "crew.docs") ||
    checkPerm(user, "crew.docs_download");
  const canDownloadDocs =
    previewCrewPortal || checkPerm(user, "crew.docs_download");

  if (!user?.crewId && !previewCrewPortal) {
    return (
      <div className="p-6 text-center text-red-500 font-bold bg-[#1a4a73] min-h-screen">
        ⚠️ هذا الحساب غير مرتبط بعضو طاقم. يرجى مراجعة الإدارة.
      </div>
    );
  }

  const myFlights = flights.filter((f) =>
    (f.crewSlots || []).some((slot) => slot.crewId === myCrewData.id)
  );

  const totalHours = useMemo(() => {
    let totalBlock = 0,
      totalFlight = 0;
    myFlights.forEach((f) => {
      const a = f.actual || {};
      if (a.blockTime) totalBlock += Number(a.blockTime) || 0;
      if (a.flightTime) totalFlight += Number(a.flightTime) || 0;
    });
    return { totalBlock, totalFlight };
  }, [myFlights]);

  const myAttachments = useMemo(() => {
    const raw = getDocs(myCrewData);
    return raw.map((d, i) => normalizeDoc(d, i)).filter(Boolean);
  }, [myCrewData]);

  const handleLogout = () => {
    if (!confirm("هل تريد تسجيل الخروج؟")) return;
    setDrawerOpen(false);
    if (typeof logout === "function") {
      logout();
    } else {
      localStorage.clear();
      window.location.reload();
    }
  };

  const navItems = [
    { id: "home", icon: Home, label: "Home" },
    {
      id: "schedule",
      icon: Calendar,
      label: "My Schedule",
      show: canSeeSchedule,
    },
    {
      id: "certificates",
      icon: Award,
      label: "Certificates",
      show: canSeeCerts,
    },
    { id: "ftl", icon: Clock, label: "FTL", show: canSeeFTL },
    { id: "manuals", icon: BookOpen, label: "Manuals", show: canSeeManuals },
    { id: "hours", icon: BarChart3, label: "My Hours", show: canSeeHours },
  ];

  return (
    <div className="min-h-screen bg-[#1a4a73] text-white font-sans" dir="ltr">
      {previewCrewPortal && (
        <div className="bg-amber-500 text-white text-xs font-bold py-1.5 px-3 text-center">
          👁️ وضع المعاينة (Admin Preview)
        </div>
      )}

      {/* ═══ Header ═══ */}
      <header className="sticky top-0 z-30 bg-[#153a5c] shadow-md">
        <div className="max-w-6xl mx-auto flex items-center gap-3 px-4 py-3">
          <button
            onClick={() => setDrawerOpen(true)}
            className="p-1.5 rounded-lg hover:bg-white/10 transition"
            aria-label="Open menu"
          >
            <Menu className="w-6 h-6 text-white" />
          </button>
          <h1 className="text-xl font-bold flex-1">Dashboard</h1>
          <div className="hidden sm:flex items-center gap-2 text-xs text-blue-200">
            <User className="w-4 h-4" />
            <span className="font-bold text-white">
              {myCrewData.fullName || user?.fullName || "Crew"}
            </span>
          </div>
          <button
            onClick={handleLogout}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600/80 hover:bg-rose-600 text-white text-xs font-bold"
            title="تسجيل الخروج"
          >
            <LogOut className="w-4 h-4" />
            <span>Exit</span>
          </button>
        </div>
      </header>

      {/* ═══ Drawer ═══ */}
      {drawerOpen && (
        <>
          <div
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
            onClick={() => setDrawerOpen(false)}
          />
          <aside className="fixed top-0 left-0 bottom-0 z-50 w-72 max-w-[85vw] bg-[#0f2c47] shadow-2xl flex flex-col">
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-sky-400 to-sky-700 flex items-center justify-center text-white font-bold">
                  {(myCrewData.fullName || user?.fullName || "C")
                    .split(" ")
                    .map((x) => x[0])
                    .join("")
                    .slice(0, 2)
                    .toUpperCase()}
                </div>
                <div className="min-w-0">
                  <div className="font-bold text-sm truncate">
                    {myCrewData.fullName || user?.fullName || "Crew"}
                  </div>
                  <div className="text-[10px] text-blue-300 truncate">
                    {myCrewData.role || user?.role || "Crew Member"}
                  </div>
                </div>
              </div>
              <button
                onClick={() => setDrawerOpen(false)}
                className="p-1.5 rounded-lg hover:bg-white/10"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <nav className="flex-1 overflow-y-auto p-2">
              {navItems
                .filter((n) => n.show !== false)
                .map((item) => {
                  const Icon = item.icon;
                  const active =
                    activeView === item.id ||
                    (item.id === "home" && !activeView);
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveView(item.id === "home" ? null : item.id);
                        setDrawerOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition mb-1 ${
                        active
                          ? "bg-sky-600 text-white font-bold"
                          : "text-blue-100 hover:bg-white/10"
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
            </nav>

            <div className="p-3 border-t border-white/10">
              <button
                onClick={handleLogout}
                className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-sm font-bold"
              >
                <LogOut className="w-4 h-4" />
                تسجيل الخروج
              </button>
            </div>
          </aside>
        </>
      )}

      {/* ═══ Main content ═══ */}
      <main className="max-w-6xl mx-auto">
        <div className="px-4 py-3 text-sm text-blue-200">
          Welcome,{" "}
          <span className="font-bold text-white">
            {myCrewData.fullName || user?.fullName || "Crew"}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 p-4 pb-20">
          {canSeeSchedule && (
            <PortalCard
              icon={Calendar}
              label="My Schedule"
              onClick={() => setActiveView("schedule")}
            />
          )}

          {canSeeCerts && (
            <PortalCard
              icon={Award}
              label="Certificates"
              onClick={() => setActiveView("certificates")}
              badge={
                canSeeFiles && myAttachments.length > 0
                  ? myAttachments.length
                  : null
              }
              badgeColor="emerald"
            />
          )}

          {canSeeFTL && (
            <PortalCard
              icon={Clock}
              label="FTL"
              onClick={() => setActiveView("ftl")}
            />
          )}
          {canSeeManuals && (
            <PortalCard
              icon={BookOpen}
              label="Manuals"
              onClick={() => setActiveView("manuals")}
            />
          )}
          {canSeeHours && (
            <PortalCard
              icon={BarChart3}
              label="My Hours"
              onClick={() => setActiveView("hours")}
            />
          )}
        </div>
      </main>

      {/* ═══ Overlay Modals ═══ */}
      {activeView && (
        <div className="fixed inset-0 z-50 bg-[#0f2c47] overflow-y-auto">
          <div className="sticky top-0 bg-[#153a5c] shadow-md z-10">
            <div className="max-w-6xl mx-auto p-3 flex justify-between items-center">
              <h2 className="font-bold text-lg capitalize">{activeView}</h2>
              <button
                onClick={() => setActiveView(null)}
                className="p-2 bg-[#235c8c] rounded-full hover:bg-[#2a6da3]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="max-w-6xl mx-auto p-4">
            {/* ═══════════ SCHEDULE ═══════════ */}
            {activeView === "schedule" && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {myFlights.length === 0 ? (
                  <p className="text-center text-blue-200 md:col-span-2">
                    No flights assigned.
                  </p>
                ) : (
                  myFlights.map((f) => (
                    <div
                      key={f.id}
                      className="bg-[#235c8c] p-3 rounded-lg border border-[#3a7bb0]"
                    >
                      <div className="flex justify-between font-bold text-lg border-b border-[#3a7bb0] pb-2 mb-2">
                        <span>{f.flightNo}</span>
                        <span>
                          {f.dep} ✈ {f.arr}
                        </span>
                      </div>
                      <div className="text-sm text-blue-100 space-y-1">
                        <p>
                          STD: {f.std ? new Date(f.std).toLocaleString() : "—"}
                        </p>
                        <p>
                          STA: {f.sta ? new Date(f.sta).toLocaleString() : "—"}
                        </p>
                        <p>Aircraft: {f.acft}</p>
                        <p>Status: {f.status}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* ═══════════ CERTIFICATES ═══════════ */}
            {activeView === "certificates" && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-blue-200 font-bold mb-3 flex items-center gap-2">
                    <Award className="w-5 h-5" /> Certificates Info
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {[
                      {
                        label: "License No",
                        value: myCrewData.licenseNo,
                        exp: myCrewData.licenseExpiry,
                      },
                      {
                        label: "Medical",
                        value: myCrewData.medicalExpiry ? "Valid" : "N/A",
                        exp: myCrewData.medicalExpiry,
                      },
                      {
                        label: "Passport No",
                        value: myCrewData.passportNo,
                        exp: myCrewData.passportExpiry,
                      },
                    ].map((doc, idx) => (
                      <div
                        key={idx}
                        className="bg-[#235c8c] p-3 rounded-lg border border-[#3a7bb0]"
                      >
                        <div className="font-bold">{doc.label}</div>
                        <div className="text-sm">{doc.value || "—"}</div>
                        {doc.exp && (
                          <div className="text-xs text-yellow-300">
                            Expiry: {doc.exp}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {canSeeFiles && (
                  <div>
                    <h3 className="text-blue-200 font-bold mb-3 flex items-center gap-2">
                      <FileText className="w-5 h-5" /> Attached Files (
                      {myAttachments.length})
                    </h3>

                    {(() => {
                      const expired = myAttachments.filter(
                        (d) => docStatus(d.expiry) === "expired"
                      ).length;
                      const critical = myAttachments.filter(
                        (d) => docStatus(d.expiry) === "critical"
                      ).length;
                      if (expired === 0 && critical === 0) return null;
                      return (
                        <div className="mb-3 space-y-2">
                          {expired > 0 && (
                            <div className="p-2.5 bg-rose-500/20 border border-rose-400 rounded-lg text-rose-200 text-xs flex items-center gap-2 font-bold">
                              <ShieldAlert className="w-4 h-4" />
                              ⚠️ {expired} مستند منتهي الصلاحية — يرجى التجديد
                            </div>
                          )}
                          {critical > 0 && (
                            <div className="p-2.5 bg-orange-500/20 border border-orange-400 rounded-lg text-orange-200 text-xs flex items-center gap-2 font-bold">
                              <ShieldAlert className="w-4 h-4" />⏰ {critical}{" "}
                              مستند ينتهي خلال 15 يوم
                            </div>
                          )}
                        </div>
                      );
                    })()}

                    {myAttachments.length === 0 ? (
                      <div className="text-center py-8 bg-[#235c8c] rounded-xl border border-[#3a7bb0]">
                        <FileText className="w-10 h-10 mx-auto text-blue-300 mb-2 opacity-50" />
                        <p className="text-blue-200 text-sm">
                          لا توجد ملفات مرفقة
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {myAttachments.map((doc, idx) => {
                          const st = docStatus(doc.expiry);
                          const days = daysUntil(doc.expiry);
                          const colorCls = getStatusColor(st);
                          const cardBorder =
                            st === "expired"
                              ? "border-rose-400 bg-rose-900/30"
                              : st === "critical"
                              ? "border-orange-400 bg-orange-900/30"
                              : st === "expiring"
                              ? "border-amber-400 bg-amber-900/20"
                              : "border-[#3a7bb0] bg-[#235c8c]";

                          return (
                            <div
                              key={idx}
                              className={`p-3 rounded-lg border flex items-start justify-between gap-3 ${cardBorder}`}
                            >
                              <div className="flex items-start gap-3 min-w-0 flex-1">
                                <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center flex-shrink-0">
                                  <FileText className="w-5 h-5 text-white" />
                                </div>
                                <div className="min-w-0 flex-1">
                                  <div
                                    className="font-bold text-sm truncate text-white"
                                    title={doc.name}
                                  >
                                    {doc.name}
                                  </div>
                                  <div className="text-[10px] text-blue-300 font-mono">
                                    {doc.type}
                                    {doc.size > 0 &&
                                      ` · ${formatFileSize(doc.size)}`}
                                  </div>
                                  {doc.expiry && days !== null && (
                                    <div className="mt-1.5 flex items-center gap-2 flex-wrap">
                                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono bg-white/10 text-blue-100">
                                        📅 {String(doc.expiry).slice(0, 10)}
                                      </span>
                                      <span
                                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold border ${colorCls}`}
                                      >
                                        {days < 0
                                          ? `منتهي منذ ${Math.abs(days)} يوم`
                                          : days === 0
                                          ? "ينتهي اليوم"
                                          : `${days} يوم متبقٍ`}
                                      </span>
                                    </div>
                                  )}
                                </div>
                              </div>
                              {doc.url ? (
                                <a
                                  href={doc.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  download={
                                    canDownloadDocs ? doc.name : undefined
                                  }
                                  className="p-2 rounded-lg bg-white/10 hover:bg-white/20 transition text-white flex-shrink-0"
                                  title={canDownloadDocs ? "تحميل" : "فتح"}
                                >
                                  {canDownloadDocs ? (
                                    <Download className="w-4 h-4" />
                                  ) : (
                                    <ExternalLink className="w-4 h-4" />
                                  )}
                                </a>
                              ) : (
                                <span className="text-[10px] text-red-300 italic">
                                  رابط غير متاح
                                </span>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}

                {!canSeeFiles && (
                  <div className="p-3 bg-amber-900/30 border border-amber-700 rounded-lg text-amber-200 text-xs flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4" /> ليس لديك صلاحية عرض
                    الملفات المرفقة
                  </div>
                )}
              </div>
            )}

            {/* ═══════════ FTL ═══════════ */}
            {activeView === "ftl" && (
              <div className="bg-white dark:bg-slate-800 rounded-lg p-2 text-black">
                <FTLModule crew={[myCrewData]} flights={myFlights} />
              </div>
            )}

            {/* ═══════════ MANUALS ═══════════ */}
            {activeView === "manuals" && (
              <div className="bg-white dark:bg-slate-800 rounded-lg p-2 text-black">
                <ManualsModule
                  settings={settings}
                  companyName={settings?.companyName}
                />
              </div>
            )}

            {/* ═══════════ HOURS ═══════════ */}
            {activeView === "hours" && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="bg-[#235c8c] p-5 rounded-xl border border-[#3a7bb0] shadow-lg">
                  <div className="text-blue-200 text-sm mb-1 uppercase tracking-wider">
                    Total Flight Hours
                  </div>
                  <div className="text-4xl font-black font-mono text-white">
                    {totalHours.totalFlight.toFixed(1)}{" "}
                    <span className="text-sm font-normal">hrs</span>
                  </div>
                </div>
                <div className="bg-[#235c8c] p-5 rounded-xl border border-[#3a7bb0] shadow-lg">
                  <div className="text-blue-200 text-sm mb-1 uppercase tracking-wider">
                    Total Block Hours
                  </div>
                  <div className="text-4xl font-black font-mono text-white">
                    {totalHours.totalBlock.toFixed(1)}{" "}
                    <span className="text-sm font-normal">hrs</span>
                  </div>
                </div>
                <div className="bg-[#235c8c] p-5 rounded-xl border border-[#3a7bb0] shadow-lg">
                  <div className="text-blue-200 text-sm mb-1 uppercase tracking-wider">
                    Total Sectors
                  </div>
                  <div className="text-4xl font-black font-mono text-white">
                    {myFlights.length}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
 * PortalCard — بطاقة موحدة للشبكة
 * ═══════════════════════════════════════════════════════════ */
function PortalCard({
  icon: Icon,
  label,
  onClick,
  badge,
  badgeColor = "emerald",
}) {
  const badgeCls =
    badgeColor === "emerald"
      ? "bg-emerald-500"
      : badgeColor === "rose"
      ? "bg-rose-500"
      : "bg-sky-500";

  return (
    <button
      onClick={onClick}
      className="relative aspect-square bg-[#235c8c] rounded-xl flex flex-col items-center justify-center p-4 hover:bg-[#2a6da3] active:scale-[0.98] transition shadow-lg border border-[#3a7bb0]"
    >
      <Icon
        className="w-12 h-12 sm:w-14 sm:h-14 text-white mb-2 sm:mb-3 drop-shadow-md"
        strokeWidth={1.5}
      />
      <span className="text-[11px] sm:text-xs font-bold text-center uppercase tracking-wider">
        {label}
      </span>
      {badge != null && badge > 0 && (
        <span
          className={`absolute top-2 end-2 ${badgeCls} text-white text-[10px] font-bold rounded-full min-w-[20px] h-5 px-1 flex items-center justify-center shadow-lg`}
        >
          {badge}
        </span>
      )}
    </button>
  );
}

export default CrewPortal;
